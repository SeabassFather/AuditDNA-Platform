export const translations = {
  en: { dashboard: { title: "Latin America Dashboard", exporters: "Exporters", /* ... */ } },
  es: { dashboard: { title: "Panel América Latina", exporters: "Exportadores", /* ... */ } }
  // ...finance, route, certs, alerts, etc.
};