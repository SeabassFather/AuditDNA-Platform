import React from "react";
export default function WaterLabUploadForm() {
  return <div>WaterLabUploadForm loaded</div>;
}