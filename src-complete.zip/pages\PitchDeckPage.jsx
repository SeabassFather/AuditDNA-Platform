import React, { useState } from "react";

export default function PitchDeckPage() {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const pitchSlides = [
    {
      title: "AuditDNA Platform",
      subtitle: "Comprehensive Audit & Compliance Solutions",
      content: "Transforming how businesses handle mortgage, agriculture, and trade finance auditing through technology and expertise.",
      image: "ðŸ“Š"
      image: "ÃƒÂ°Ã…Â¸Ã¢â‚¬Å“Ã…Â "
    },
    {
      title: "The Problem",
      subtitle: "Costly Errors & Compliance Gaps",
      content: "â€¢ 75% of mortgage files contain errors\nâ€¢ Agricultural compliance violations cost $50K+ annually\nâ€¢ Small businesses lose 20% cash flow to delayed payments",
      image: "âš ï¸"
      content: "ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ 75% of mortgage files contain errors\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Agricultural compliance violations cost $50K+ annually\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Small businesses lose 20% cash flow to delayed payments",
      image: "ÃƒÂ¢Ã…Â¡Ã‚Â ÃƒÂ¯Ã‚Â¸Ã‚Â"
    },
    {
      title: "Our Solution",
      subtitle: "Automated Audit & Compliance Platform",
      content: "â€¢ AI-powered document analysis\nâ€¢ Real-time compliance monitoring\nâ€¢ Integrated financial solutions\nâ€¢ Expert human oversight",
      image: "ðŸŽ¯"
      content: "ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ AI-powered document analysis\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Real-time compliance monitoring\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Integrated financial solutions\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Expert human oversight",
      image: "ÃƒÂ°Ã…Â¸Ã…Â½Ã‚Â¯"
    },
    {
      title: "Market Opportunity",
      subtitle: "$2.5B Addressable Market",
      content: "â€¢ Mortgage auditing: $800M market\nâ€¢ Agriculture compliance: $1.2B market\nâ€¢ Trade finance: $500M market\nâ€¢ Growing 15% annually",
      image: "ðŸ“ˆ"
      content: "ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Mortgage auditing: $800M market\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Agriculture compliance: $1.2B market\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Trade finance: $500M market\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Growing 15% annually",
      image: "ÃƒÂ°Ã…Â¸Ã¢â‚¬Å“Ã‹â€ "
    },
    {
      title: "Revenue Streams",
      subtitle: "Multiple Income Sources",
      content: "â€¢ Per-audit fees: $500-$5,000\nâ€¢ Subscription services: $200-$2,000/month\nâ€¢ Success-based fees: 20-30% of recoveries\nâ€¢ Partnership referrals: 5-15%",
      image: "ðŸ’°"
      content: "ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Per-audit fees: $500-$5,000\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Subscription services: $200-$2,000/month\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Success-based fees: 20-30% of recoveries\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Partnership referrals: 5-15%",
      image: "ÃƒÂ°Ã…Â¸Ã¢â‚¬â„¢Ã‚Â°"
    },
    {
      title: "Competitive Advantage",
      subtitle: "What Makes Us Different",
      content: "â€¢ Multi-industry expertise\nâ€¢ Technology + human oversight\nâ€¢ Proven track record\nâ€¢ Integrated financial solutions\nâ€¢ Scalable platform",
      image: "ðŸ†"
      content: "ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Multi-industry expertise\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Technology + human oversight\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Proven track record\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Integrated financial solutions\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Scalable platform",
      image: "ÃƒÂ°Ã…Â¸Ã‚ÂÃ¢â‚¬Â "
    },
    {
      title: "Traction",
      subtitle: "Growing Customer Base",
      content: "â€¢ 500+ completed audits\nâ€¢ $15M in client recoveries\nâ€¢ 95% client satisfaction\nâ€¢ 40% month-over-month growth",
      image: "ðŸš€"
      content: "ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ 500+ completed audits\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ $15M in client recoveries\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ 95% client satisfaction\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ 40% month-over-month growth",
      image: "ÃƒÂ°Ã…Â¸Ã…Â¡Ã¢â€šÂ¬"
    },
    {
      title: "Financial Projections",
      subtitle: "Path to Profitability",
      content: "Year 1: $500K revenue\nYear 2: $2M revenue\nYear 3: $8M revenue\nBreakeven: Month 18",
      image: "ðŸ“Š"
      image: "ÃƒÂ°Ã…Â¸Ã¢â‚¬Å“Ã…Â "
    },
    {
      title: "Team",
      subtitle: "Experienced Leadership",
      content: "â€¢ CEO: 15 years financial services\nâ€¢ CTO: Former fintech architect\nâ€¢ COO: Compliance expert\nâ€¢ 20+ experienced auditors",
      image: "ðŸ‘¥"
      content: "ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ CEO: 15 years financial services\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ CTO: Former fintech architect\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ COO: Compliance expert\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ 20+ experienced auditors",
      image: "ÃƒÂ°Ã…Â¸Ã¢â‚¬ËœÃ‚Â¥"
    },
    {
      title: "Investment Ask",
      subtitle: "$2M Series A",
      content: "â€¢ Product development: 40%\nâ€¢ Team expansion: 35%\nâ€¢ Marketing & sales: 20%\nâ€¢ Working capital: 5%",
      image: "ðŸ’¼"
      content: "ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Product development: 40%\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Team expansion: 35%\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Marketing & sales: 20%\nÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¢ Working capital: 5%",
      image: "ÃƒÂ°Ã…Â¸Ã¢â‚¬â„¢Ã‚Â¼"
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % pitchSlides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + pitchSlides.length) % pitchSlides.length);
  };

  const goToSlide = (index) => {
    setCurrentSlide(index);
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      {/* Presentation Mode */}
      <div className="bg-white rounded-lg shadow-lg overflow-hidden mb-8">
        {/* Slide Content */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-800 p-12 text-white min-h-96 flex flex-col justify-center">
          <div className="text-center">
            <div className="text-6xl mb-6">{pitchSlides[currentSlide].image}</div>
            <h1 className="text-4xl font-bold mb-4">{pitchSlides[currentSlide].title}</h1>
            <h2 className="text-xl mb-8 text-blue-100">{pitchSlides[currentSlide].subtitle}</h2>
            <div className="bg-white bg-opacity-10 rounded-lg p-6 max-w-3xl mx-auto">
              <pre className="text-left whitespace-pre-wrap text-lg leading-relaxed">
                {pitchSlides[currentSlide].content}
              </pre>
            </div>
          </div>
        </div>

        {/* Navigation Controls */}
        <div className="bg-gray-100 px-6 py-4 flex items-center justify-between">
          <button
            onClick={prevSlide}
            disabled={currentSlide === 0}
            className="flex items-center px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <svg className="h-4 w-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Previous
          </button>

          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-600">
              {currentSlide + 1} of {pitchSlides.length}
            </span>
            <div className="flex space-x-1">
              {pitchSlides.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToSlide(index)}
                  className={`w-2 h-2 rounded-full ${
                    index === currentSlide ? 'bg-blue-600' : 'bg-gray-300'
                  }`}
                />
              ))}
            </div>
          </div>

          <button
            onClick={nextSlide}
            disabled={currentSlide === pitchSlides.length - 1}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Next
            <svg className="h-4 w-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>

      {/* Slide Overview */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Slide Overview</h2>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {pitchSlides.map((slide, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`p-3 rounded-lg border-2 transition-colors ${
                index === currentSlide
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 bg-white hover:border-gray-300'
              }`}
            >
              <div className="text-2xl mb-2">{slide.image}</div>
              <div className="text-xs font-medium text-gray-700">{slide.title}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Presentation Tools */}
      <div className="mt-8 bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Presentation Tools</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <button className="w-full bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 font-medium mb-2">
              Download PDF
            </button>
            <p className="text-sm text-gray-600">Get a PDF version for sharing</p>
          </div>
          
          <div className="text-center">
            <button 
              onClick={() => {
                if (document.documentElement.requestFullscreen) {
                  document.documentElement.requestFullscreen();
                }
              }}
              className="w-full bg-purple-600 text-white py-3 px-4 rounded-lg hover:bg-purple-700 font-medium mb-2"
            >
              Fullscreen Mode
            </button>
            <p className="text-sm text-gray-600">Present in fullscreen</p>
          </div>
          
          <div className="text-center">
            <button className="w-full bg-orange-600 text-white py-3 px-4 rounded-lg hover:bg-orange-700 font-medium mb-2">
              Share Link
            </button>
            <p className="text-sm text-gray-600">Share with investors</p>
          </div>
        </div>
      </div>

      {/* Speaker Notes */}
      <div className="mt-8 bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Speaker Notes - Slide {currentSlide + 1}</h2>
        <div className="bg-gray-50 rounded-lg p-4">
          <p className="text-gray-700">
            {currentSlide === 0 && "Start with a strong opening. Introduce AuditDNA as the comprehensive solution for audit and compliance challenges across multiple industries."}
            {currentSlide === 1 && "Highlight the pain points that your audience can relate to. Use specific statistics to demonstrate the scope of the problem."}
            {currentSlide === 2 && "Show how your solution directly addresses each problem mentioned in the previous slide. Emphasize the technology + human expertise combination."}
            {currentSlide === 3 && "Present market data confidently. These numbers should excite investors about the opportunity size."}
            {currentSlide === 4 && "Break down your revenue model clearly. Show multiple income streams to demonstrate stability and growth potential."}
            {currentSlide === 5 && "Differentiate yourself from competitors. Explain why customers choose you over alternatives."}
            {currentSlide === 6 && "Use specific metrics to prove traction. This builds credibility and shows momentum."}
            {currentSlide === 7 && "Present realistic but ambitious projections. Be prepared to defend your assumptions."}
            {currentSlide === 8 && "Highlight team credentials and expertise. Investors bet on people as much as ideas."}
            {currentSlide === 9 && "Be specific about fund usage. Show you have a clear plan for the investment."}
          </p>
        </div>
      </div>
    </div>
  );
}