import React from "react";

export default function LatAmBuyersNetwork() {
  return (
    <div className="p-6">
      LatAm Buyers Network module tab.
    </div>
  );
}