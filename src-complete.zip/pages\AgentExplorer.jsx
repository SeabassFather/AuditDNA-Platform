import React, { useState } from "react";

// ...full code as previously provided...

export default AgentRegistrationCard;