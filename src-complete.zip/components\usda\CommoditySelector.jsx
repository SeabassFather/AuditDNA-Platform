import React from "react";
export default function CommoditySelector({ selected, onSelect }) {
  return (
    <div className="p-6">
      <p className="font-bold">Commodity Selector — choose commodity</p>
    </div>
  );
}