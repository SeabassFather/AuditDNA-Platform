import React from "react";

const Footer = () => {
  return (
    <footer>
      <div>
        © 2024 AuditDNA. All rights reserved. | Licensed Financial Services Provider
      </div>
    </footer>
  );
};

export default Footer;