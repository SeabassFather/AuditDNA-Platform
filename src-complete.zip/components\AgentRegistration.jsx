import React, { useState } from 'react';
import { UserCheck, Building2, Mail, Phone, AlertCircle, Banknote } from 'lucide-react';
import MexicoRefiCard from "./MexicoRefiCard.jsx"; // If AgentRegistration.jsx and MexicoRefiCard.jsx are both in components/