export default function RealEstate() {
  return <div className="p-8 text-3xl font-bold">Real Estate Module Coming Soon!</div>;
}
