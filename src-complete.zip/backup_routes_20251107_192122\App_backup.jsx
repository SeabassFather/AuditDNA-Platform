import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { LanguageProvider } from "./LanguageContext";
import HomePage from "./pages/HomePage";

// === Dashboard Modules ===
import WaterAnalysisDashboard from "./pages/WaterAnalysisDashboard";
import SoilAnalysisDashboard from "./pages/SoilAnalysisDashboard";
import FuelAnalysisDashboard from "./pages/FuelAnalysisDashboard";
import AlcoholAnalysisDashboard from "./pages/AlcoholAnalysisDashboard";
import AgScienceDashboard from "./pages/AgScienceDashboard";
import ResultsPortal from "./pages/ResultsPortal";
import TraceabilityDashboard from "./pages/TraceabilityDashboard";
import LatinAmericaDashboard from "./pages/LatinAmericaDashboard";
import FinancialServices from "./pages/FinancialServices";
import USDA from "./pages/USDA";
import AdminDashboard from "./pages/AdminDashboard";
import FiveVerificationEngines from "./pages/FiveVerificationEngines";
import FrozenAvocadoGuacamole from "./pages/FrozenAvocadoGuacamole";

function App() {
  return (
    <LanguageProvider>
      <Router>
        <Routes>
          {/* ====== HOME ====== */}
          <Route path="/" element={<HomePage />} />

          {/* ====== CORE DASHBOARDS ====== */}
          <Route path="/water" element={<WaterAnalysisDashboard />} />
          <Route path="/soil" element={<SoilAnalysisDashboard />} />
          <Route path="/fuel" element={<FuelAnalysisDashboard />} />
          <Route path="/alcohol" element={<AlcoholAnalysisDashboard />} />
          <Route path="/ag" element={<AgScienceDashboard />} />
          <Route path="/results" element={<ResultsPortal />} />
          <Route path="/dashboard/traceability" element={<TraceabilityDashboard />} />

          {/* ====== ADVANCED / REGIONAL ====== */}
          <Route path="/latin" element={<LatinAmericaDashboard />} />
          <Route path="/usda" element={<USDA />} />
          <Route path="/financial" element={<FinancialServices />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/engines" element={<FiveVerificationEngines />} />
          <Route path="/frozen" element={<FrozenAvocadoGuacamole />} />

          {/* ====== 404 FALLBACK ====== */}
          <Route
            path="*"
            element={
              <div className="min-h-screen flex items-center justify-center bg-gray-900 text-white text-2xl">
                🚫 Route not found — AuditDNA Frontend
              </div>
            }
          />
        </Routes>
      </Router>
    </LanguageProvider>
  );
}

export default App;
