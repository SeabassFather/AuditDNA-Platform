import React from "react";

export default function EscrowFeatureCard() {
  return (
    <div style={{
      background: "#e0f2fe",
      borderRadius: "12px",
      padding: "24px",
      margin: "24px 0",
      boxShadow: "0 2px 8px rgba(0,0,0,0.07)"
    }}>
      <h2 style={{
        color: "#1e40af",
        fontWeight: 700,
        marginBottom: 8,
        fontSize: "1.5rem"
      }}>
        Open Escrow with First American Title
      </h2>
      <p style={{
        color: "#334155",
        marginBottom: 16,
        fontSize: "1rem"
      }}>
        Ready to proceed? Start the Title & Escrow process with First American Title.
      </p>
      <button
        style={{
          background: "#1e40af",
          color: "#fff",
          padding: "10px 32px",
          borderRadius: 8,
          fontWeight: 700,
          border: "none",
          cursor: "pointer",
          fontSize: "1rem",
          boxShadow: "0 1px 4px rgba(30,64,175,0.15)"
        }}
      >
        Start Escrow
      </button>
    </div>
  );
}