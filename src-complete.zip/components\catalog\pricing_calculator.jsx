import React from "react";
export default function PricingCalculator() {
  return (
    <div className="p-8">Pricing Calculator goes here.</div>
  );
}