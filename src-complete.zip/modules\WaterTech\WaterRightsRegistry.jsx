import React from "react";
export default function WaterRightsRegistry() {
  return <div>WaterRightsRegistry loaded</div>;
}