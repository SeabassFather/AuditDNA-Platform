export const auditDNAServices = {
  agriculture: {
    title: "Agriculture & Trade",
    icon: "ðŸŒ¾",
    count: 26,
    gradient: "linear-gradient(135deg, #84cc16, #10b981)",
    services: [
      "USDA Weekly Pricing (W1â€“W26)",
    icon: "ÃƒÂ°Ã…Â¸Ã…â€™Ã‚Â¾",
    count: 26,
    gradient: "linear-gradient(135deg, #84cc16, #10b981)",
    services: [
      "USDA Weekly Pricing (W1ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Å“W26)",
      // ... all services
    ]
  },
  // ... all other categories
};


