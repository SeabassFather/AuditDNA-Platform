import React from "react";
export default function FiveYearOverlay({ data }) {
  return (
    <div className="p-6 font-bold">
      FiveYearOverlay — overlay multi-year pricing trends here.
    </div>
  );
}