import React from "react";
export default function AuditReport(){ return <h2> Audit Reports</h2>; }



