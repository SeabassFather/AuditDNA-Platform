import React from "react";

const Dashboard = () => (
  <div>
    <h1>Dashboard</h1>
    <p>Advanced audit and compliance solutions for mortgage, agriculture, and trade finance industries.</p>
    {/* Add widgets, charts, or dashboard UI as needed */}
  </div>
);

export default Dashboard;
