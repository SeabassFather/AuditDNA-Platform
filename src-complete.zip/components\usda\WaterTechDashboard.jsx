import React from "react";
export default function WaterTechDashboard() {
  return <div className="p-8 font-bold text-2xl">WaterTech Dashboard — lab results and analysis.</div>;
}