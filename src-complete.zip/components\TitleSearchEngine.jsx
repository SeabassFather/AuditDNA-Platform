import React from "react";

export default function TitleSearchEngine() {
  return (
    <div style={{
      background: "#f1f5f9",
      borderRadius: "12px",
      padding: "24px",
      margin: "24px 0",
      boxShadow: "0 2px 8px rgba(0,0,0,0.07)"
    }}>
      <h2 style={{
        color: "#075985",
        fontWeight: 700,
        marginBottom: 8,
        fontSize: "1.3rem"
      }}>
        Title Search Engine
      </h2>
      <p style={{
        color: "#334155",
        marginBottom: 16,
        fontSize: "1rem"
      }}>
        Search and select a title company (feature coming soon).
      </p>
      <button
        style={{
          background: "#0ea5e9",
          color: "#fff",
          padding: "8px 28px",
          borderRadius: 8,
          fontWeight: 700,
          border: "none",
          cursor: "pointer",
          fontSize: "1rem"
        }}
      >
        Search Title Companies
      </button>
    </div>
  );
}