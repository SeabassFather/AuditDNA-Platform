﻿import React from "react";
import { useNavigate } from "react-router-dom";
import { useLanguage } from "../contexts/LanguageContext";
import audioSystem from "../utils/audioSystem";

const HomePage = () => {
  const navigate = useNavigate();
  const { language } = useLanguage();

  const handleNavigation = (path) => {
    audioSystem.playSound("click");
    navigate(path);
  };

  const sections = [
    {
      title: "⚡ Quick Access",
      cards: [
        { icon: "🔍", name: "Universal Search", desc: "Search across all modules with AI-powered results", tag: "SEARCH", color: "bg-indigo-500", path: "/search" },
        { icon: "📈", name: "Real-Time Analytics", desc: "Live data dashboards and predictive intelligence", tag: "ANALYTICS", color: "bg-purple-500", path: "/analytics" },
        { icon: "📄", name: "Reports Center", desc: "Generate and export professional reports", tag: "REPORTS", color: "bg-pink-500", path: "/reports" },
        { icon: "📚", name: "Help Center", desc: "Documentation, tutorials, and 24/7 support", tag: "HELP", color: "bg-amber-500", path: "/help" },
      ]
    },
    {
      title: "📊 Primary Dashboards",
      cards: [
        { icon: "🌎", name: "Latin America", desc: "Regional compliance tracking, port analytics, and trade routes", tag: "REGIONAL", color: "bg-emerald-500", path: "/latin-america" },
        { icon: "⚙️", name: "Admin", desc: "System administration and user management", tag: "ADMIN", color: "bg-gray-400", path: "/admin" },
        { icon: "🔬", name: "AgScience", desc: "Agricultural science data and compliance modules", tag: "CORE", color: "bg-green-600", path: "/agscience" },
      ]
    },
    {
      title: "✅ Compliance & Verification",
      cards: [
        { icon: "🔍", name: "Traceability", desc: "End-to-end product tracking and chain of custody", tag: "TRACKING", color: "bg-lime-500", path: "/traceability" },
        { icon: "🇺🇸", name: "USDA", desc: "USDA compliance and certification management", tag: "REGULATORY", color: "bg-yellow-500", path: "/usda" },
        { icon: "🛡️", name: "Five Verification Engines", desc: "Multi-layer verification and validation system", tag: "VERIFICATION", color: "bg-amber-400", path: "/verification" },
      ]
    },
    {
      title: "🥑 Product Modules",
      cards: [
        { icon: "🧊", name: "Frozen Avocado & Guacamole", desc: "Specialized tracking for frozen avocado products", tag: "PRODUCT", color: "bg-green-600", path: "/frozen-avocado" },
      ]
    },
    {
      title: "💰 Financial Services",
      cards: [
        { icon: "💳", name: "Financial Services", desc: "Payment processing and financial compliance", tag: "FINANCE", color: "bg-lime-400", path: "/financial" },
      ]
    },
  ];

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-emerald-50 via-slate-50 to-yellow-50 text-slate-800 py-16 px-8 overflow-x-hidden">
      <div className="max-w-7xl mx-auto">
        <header className="text-center mb-12">
          <h1 className="text-5xl md:text-6xl font-extrabold text-emerald-700 mb-3">🧬 AuditDNA Platform</h1>
          <p className="text-lg md:text-xl text-emerald-600 font-medium">Complete Agricultural Compliance & Traceability System</p>
        </header>

        {sections.map((section, sidx) => (
          <div key={sidx} className="mb-16">
            <h2 className="text-2xl font-bold text-emerald-700 border-b-4 border-emerald-300 inline-block mb-8 pb-2">
              {section.title}
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {section.cards.map((card, idx) => (
                <button
                  key={idx}
                  onClick={() => handleNavigation(card.path)}
                  onMouseEnter={() => audioSystem.playHover?.()}
                  onClickCapture={() => audioSystem.playSound?.("click")}
                  className="bg-white rounded-xl border-2 border-emerald-100 shadow-md hover:shadow-2xl transition-all duration-300 p-6 text-left hover:-translate-y-2 hover:border-emerald-400"
                >
                  <h3 className="text-xl font-semibold text-emerald-700 mb-2 flex items-center gap-2">{card.icon} {card.name}</h3>
                  <p className="text-slate-500 text-sm leading-relaxed mb-3">{card.desc}</p>
                  <span className={inline-block text-white text-xs font-semibold rounded-full px-3 py-1 }>
                    {card.tag}
                  </span>
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HomePage;
