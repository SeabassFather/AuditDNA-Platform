import React from "react";
export default function WaterZoneMap() {
  return <div>WaterZoneMap loaded</div>;
}