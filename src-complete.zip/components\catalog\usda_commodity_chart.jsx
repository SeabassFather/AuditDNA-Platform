import React from "react";
export default function USDACommodityChart() {
  return (
    <div className="p-8">USDA Commodity Chart module.</div>
  );
}