import React from "react";
import DocuSignPanel from "../features/docusign/DocuSignPanel";
export default function DocuSignPage() {
  return <DocuSignPanel />;
}
