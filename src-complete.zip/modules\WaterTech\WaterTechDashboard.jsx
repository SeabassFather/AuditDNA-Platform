import React from "react";
export default function WaterTechDashboard() {
  return <div>WaterTechDashboard loaded</div>;
}