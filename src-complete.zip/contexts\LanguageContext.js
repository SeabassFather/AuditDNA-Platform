import React, { createContext, useContext, useState } from "react";
import { translations } from "../components/translations"; // CORRECT PATH

const LanguageContext = createContext();

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState(localStorage.getItem("language") || "en");
  const t = translations[language];

  function toggleLanguage() {
    setLanguage((prev) => {
      const newLang = prev === "en" ? "es" : "en";
      localStorage.setItem("language", newLang);
      return newLang;
    });
  }

  return (
    <LanguageContext.Provider value={{ language, t, toggleLanguage }}>
      {children}
    </LanguageContext.Provider>
  );
};

export function useLanguage() {
  return useContext(LanguageContext);
}