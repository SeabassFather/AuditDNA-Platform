import React from "react";
export default function GeoHeatmap({ regions }) {
  return (
    <div className="p-6">GeoHeatmap: Color-coded USDA volumes go here.</div>
  );
}