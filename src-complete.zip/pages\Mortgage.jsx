﻿import React from 'react';

export default function Mortgage() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1 style={{ fontSize: '2rem', fontWeight: 'bold', marginBottom: '1rem' }}>Mortgages</h1>
      <p>Mortgage services coming soon...</p>
    </div>
  );
}
