﻿import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { LanguageProvider } from "./LanguageContext";
import HomePage from "./pages/HomePage";

# Dynamic Imports
import AdminDashboard from './pages/AdminDashboard.jsx';
import AgentDashboard from './pages/AgentDashboard.jsx';
import ComplianceDashboard from './pages/ComplianceDashboard.jsx';
import Dashboard from './pages/Dashboard.jsx';
import LatinAmericaDashboard from './pages/LatinAmericaDashboard.jsx';
import Megadashboard from './pages/Megadashboard.jsx';
import ProduceDashboard from './pages/ProduceDashboard.jsx';
import ComplianceDashboard from './pages/compliance/ComplianceDashboard.jsx';
import EcoDashboard from './pages/eco/EcoDashboard.jsx';
import FinancialDashboard from './pages/factoring/FinancialDashboard.jsx';
import ProduceDashboard from './pages/produce/ProduceDashboard.jsx';
import ProduceDashboard from './pages/protein/ProduceDashboard.jsx';
import ProteinDashboard from './pages/protein/ProteinDashboard.jsx';
import RealEstateDashboard from './pages/realestate/RealEstateDashboard.jsx';
import TraceabilityDashboard from './pages/traceability/TraceabilityDashboard.jsx';
import AuditDNAProducePlatformDashboard from './pages/usda/AuditDNAProducePlatformDashboard.jsx';
import USDAIntelligenceDashboard from './pages/usda/USDAIntelligenceDashboard.jsx';
import FactoringDashboard from './pages/watertech/FactoringDashboard.jsx';
import WaterTechDashboard from './pages/watertech/WaterTechDashboard.jsx';

function App() {
  return (
    <LanguageProvider>
      <Router>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path='/' element={<AdminDashboard />} />
          <Route path='/' element={<AgentDashboard />} />
          <Route path='/' element={<ComplianceDashboard />} />
          <Route path='/' element={<Dashboard />} />
          <Route path='/' element={<LatinAmericaDashboard />} />
          <Route path='/' element={<Megadashboard />} />
          <Route path='/' element={<ProduceDashboard />} />
          <Route path='/' element={<ComplianceDashboard />} />
          <Route path='/' element={<EcoDashboard />} />
          <Route path='/' element={<FinancialDashboard />} />
          <Route path='/' element={<ProduceDashboard />} />
          <Route path='/' element={<ProduceDashboard />} />
          <Route path='/' element={<ProteinDashboard />} />
          <Route path='/' element={<RealEstateDashboard />} />
          <Route path='/' element={<TraceabilityDashboard />} />
          <Route path='/' element={<AuditDNAProducePlatformDashboard />} />
          <Route path='/' element={<USDAIntelligenceDashboard />} />
          <Route path='/' element={<FactoringDashboard />} />
          <Route path='/' element={<WaterTechDashboard />} />
          <Route
            path="*"
            element={
              <div className='min-h-screen flex items-center justify-center bg-gray-900 text-white text-2xl'>
                🚫 Route not found — AuditDNA Frontend
              </div>
            }
          />
        </Routes>
      </Router>
    </LanguageProvider>
  );
}

export default App;
