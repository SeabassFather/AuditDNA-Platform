import React, { useState } from "react";
import Prices from "./Prices.jsx";
import ProduceTrendsAll from "./producetrendsall.jsx";
import ProduceMarketPie from "./producemarketpie.jsx";
import ProducePriceChart from "./producepricechart.jsx";
import ProduceInquiry from "./ProduceInquiry.jsx";
import Produce from "./Produce.jsx";

// Features & user benefits
const FEATURE_LIST = [
  "🔒 Real-time institutional pricing & volume analytics",
  "📊 Multi-year market forecasts with instant chart and trend visualization",
  "🌎 Regional cost calculator by product size and geography",
  "💼 Full buyer directory and B2B partnership gateway",
  "🧑‍🌾 Verified growers/exporters filterable by certifications, volume, location",
  "🥑 Avocado-centric tools that adapt to other produce: tomatoes, peppers, limes, etc.",
  "📈 Compare up to 10 commodities' historic price action and stats",
  "🍰 5-year market share pie for quick opportunity recognition",
  "⬇️ Download any chart or dataset in CSV for reporting",
  "📨 Inquiry form: instant price, compliance, or partnership request"
];

const MODULE_TABS = [
  { key: "analytics", label: "Market Trends", emoji: "📈" },
  { key: "regional", label: "Regional Prices", emoji: "🌎" },
  { key: "avocado", label: "Avocado Sizing", emoji: "🥑" },
  { key: "buyers", label: "Buyers Directory", emoji: "💼" },
  { key: "growers", label: "Growers & Exporters", emoji: "🧑‍🌾" },
  { key: "inquiry", label: "Inquiry Portal", emoji: "❓" }
];

export default function ProduceDashboard() {
  const [activeTab, setActiveTab] = useState("analytics");

  return (
    <div style={{
      background: "linear-gradient(135deg, #eaffee 0%, #f0f5ff 100%)",
      minHeight: "100vh",
      paddingBottom: 40
    }}>
      {/* Hero Banner & Features */}
      <header style={{
        padding: "2rem 0 1.5rem 0",
        background: "linear-gradient(90deg, #16a34a 0%, #38bdf8 100%)",
        color: "#fff",
        borderRadius: "0 0 26px 26px",
        boxShadow: "0 10px 40px #16a34a22",
        marginBottom: "1.5rem"
      }}>
        <div style={{ maxWidth: 1300, margin: "0 auto" }}>
          <h1 style={{
            fontSize: "2.7rem", fontWeight: 900,
            textShadow: "0 1px 20px #029e5b55",
            letterSpacing: "1px", display: "flex",
            alignItems: "center", gap: "0.6rem"
          }}>
            <span role="img" aria-label="avocado" style={{ fontSize: "2.4rem" }}>🥑</span>
            AuditDNA Produce Dashboard
          </h1>
          <p style={{ fontSize: "1.15rem", marginBottom: "0.9rem" }}>
            Avocado Intelligence. Institutional Analytics for Real-Time Produce Markets.
          </p>
          <div style={{
            display: "flex", gap: 12, flexWrap: "wrap",
            marginTop: 18, fontWeight: 600, fontSize: "1rem"
          }}>
            {FEATURE_LIST.map((benefit, i) => (
              <span key={i} style={{
                background: "#f1f5f9",
                color: "#084e2e",
                borderRadius: 16,
                padding: "0.7rem 1rem",
                marginBottom: "0.5rem",
                boxShadow: "0 2px 12px #16a34a11"
              }}>
                {benefit}
              </span>
            ))}
          </div>
        </div>
      </header>

      {/* Tab Navigation */}
      <nav style={{
        display: "flex",
        gap: "2.2rem",
        justifyContent: "center",
        background: "#fff",
        borderBottom: "2px solid #22d3ee33",
        borderRadius: "0 0 22px 22px",
        boxShadow: "0 2px 13px #16a34a18",
        padding: "0.5rem 0 1.2rem 0",
        marginBottom: "2rem"
      }}>
        {MODULE_TABS.map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            style={{
              padding: "0.8rem 2.15rem",
              fontWeight: "bold",
              fontSize: "1.13rem",
              background: activeTab === tab.key ? "#16a34a" : "#f8fafc",
              color: activeTab === tab.key ? "#fff" : "#084e2e",
              boxShadow: activeTab === tab.key
                ? "0 2px 12px #16a34a22"
                : "0 1px 6px #16a34a09",
              border: "none",
              borderRadius: "16px 16px 5px 5px",
              cursor: "pointer",
              transition: "all 0.17s"
            }}
          >
            <span style={{ fontSize: "1.22em", marginRight: "6px" }}>{tab.emoji}</span>
            {tab.label}
          </button>
        ))}
      </nav>

      <main style={{ maxWidth: 1400, margin: "0 auto", padding: "0 24px" }}>
        {/* Market Analytics Tab */}
        {activeTab === "analytics" && (
          <section>
            <div style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(480px, 1fr))",
              gap: "2.4rem",
              marginBottom: "2.7rem"
            }}>
              <div style={{ background: "#fff", borderRadius: "22px", boxShadow: "0 3px 21px #1e3a8a09", padding: "1.6rem" }}>
                <h2 style={{
                  fontSize: "1.24rem",
                  color: "#16a34a",
                  fontWeight: 800,
                  marginBottom: "0.9rem"
                }}>
                  Multi-Year Market Price Trends
                </h2>
                <ProduceTrendsAll areaTitle="USDA Multi-Commodity" />
              </div>
              <div style={{ background: "#fff", borderRadius: "22px", boxShadow: "0 3px 21px #1e3a8a09", padding: "1.6rem" }}>
                <h2 style={{
                  fontSize: "1.24rem",
                  color: "#14b8a6",
                  fontWeight: 800,
                  marginBottom: "0.9rem"
                }}>
                  Market Pie | 5-Year Avg Price
                </h2>
                <ProduceMarketPie />
              </div>
            </div>
            <div style={{ background: "#fff", borderRadius: "18px", boxShadow: "0 2px 16px #a7f3d040", padding: "2rem", marginBottom: "2.7rem" }}>
              <h2 style={{ fontSize: "1.19rem", color: "#38bdf8", fontWeight: 800, marginBottom: "1.1rem" }}>
                Avocado Price Chart · Last 5 Years
              </h2>
              <ProducePriceChart
                commodity="Avocado"
                usdaParams={{
                  commodity_desc: "AVOCADOS",
                  statisticcat_desc: "PRICE RECEIVED",
                  unit_desc: "DOLLARS / LB"
                }}
              />
            </div>
            <div style={{ background: "#f0fdf4", borderRadius: "18px", padding: "2rem" }}>
              <Prices />
            </div>
          </section>
        )}

        {/* Regional Price Calculator Tab */}
        {activeTab === "regional" && (
          <section>
            <div style={{
              background: "#fff",
              borderRadius: "22px",
              boxShadow: "0 3px 21px #1e3a8a09",
              padding: "2rem"
            }}>
              <h2 style={{ fontSize: "1.23rem", color: "#16a34a", fontWeight: 800, marginBottom: "1rem" }}>
                Regional Price Calculator (Avocado)
              </h2>
              <Produce />
            </div>
          </section>
        )}

        {/* Avocado Sizing Tab */}
        {activeTab === "avocado" && (
          <section>
            <div style={{
              background: "#fff",
              borderRadius: "22px",
              boxShadow: "0 3px 21px #1e3a8a09",
              padding: "2rem"
            }}>
              <h2 style={{ fontSize: "1.22rem", color: "#22c55e", fontWeight: 800, marginBottom: "1rem" }}>
                Sizing & Regional Price Grid
              </h2>
              <Produce />
            </div>
          </section>
        )}

        {/* Buyers Directory Tab */}
        {activeTab === "buyers" && (
          <section>
            <div style={{
              background: "#fff",
              borderRadius: "22px",
              boxShadow: "0 3px 21px #1e3a8a09",
              padding: "2rem"
            }}>
              <h2 style={{ fontSize: "1.19rem", color: "#38bdf8", fontWeight: 800, marginBottom: "1rem" }}>
                Major Buyers Directory
              </h2>
              <Produce />
            </div>
          </section>
        )}

        {/* Growers Tab */}
        {activeTab === "growers" && (
          <section>
            <div style={{
              background: "#fff",
              borderRadius: "22px",
              boxShadow: "0 3px 21px #1e3a8a09",
              padding: "2rem"
            }}>
              <h2 style={{ fontSize: "1.18rem", color: "#10b981", fontWeight: 800, marginBottom: "1rem" }}>
                Top Growers & Exporters
              </h2>
              <Produce />
            </div>
          </section>
        )}

        {/* Inquiry Portal Tab */}
        {activeTab === "inquiry" && (
          <section>
            <div style={{
              background: "#fff",
              borderRadius: "22px",
              boxShadow: "0 3px 21px #1e3a8a09",
              padding: "2rem"
            }}>
              <h2 style={{ fontSize: "1.13rem", color: "#c026d3", fontWeight: 800, marginBottom: "1rem" }}>
                Inquiry Portal
              </h2>
              <ProduceInquiry />
              <div style={{ marginTop: "2rem", color: "#3b82f6", fontSize: "1rem" }}>
                <strong>Pro Tip:</strong> Request quotes, compliance docs, market insights or partnership right here.
              </div>
            </div>
          </section>
        )}
      </main>

      {/* Sticky Benefits Footer */}
      <footer style={{
        marginTop: 60,
        padding: "2rem 0",
        background: "linear-gradient(90deg, #1e293b 0%, #99f6e4 100%)",
        color: "#fff",
        textAlign: "center",
        borderRadius: "22px 22px 0 0",
        fontWeight: 600
      }}>
        <div>
          Powered by AuditDNA Platform · All analytics, pricing, and market data direct from USDA, Avocado industry, and institutional sources.
        </div>
        <div style={{ marginTop: "0.7rem", fontSize: "1rem", fontWeight: 700 }}>
          Need more? Use Inquiry or reach out to Admin for custom reports.
        </div>
      </footer>
    </div>
  );
}