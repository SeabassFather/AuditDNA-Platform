import React, { useState } from "react";
import PricingCalculator from "../components/catalog/pricing_calculator";
import MarketTrendsTab from "../components/catalog/market_trends_tab";
import USDACommodityChart from "../components/usda/usda_commodity_chart";
import LatAmBuyersNetwork from "../components/catalog/latam_buyers_network";
import CertificationsTab from "../components/catalog/certifications_tab";
import ExcelExportComponent from "../components/catalog/excel_export_component";
import USDAWeeklyReports from "../components/usda/Tab5WeeklyReports";
// ... rest of your code unchanged ...