import React from "react";

export default function CertificationsTab() {
  return (
    <div className="p-6">
      Certifications Tab module tab.
    </div>
  );
}