import React from "react";
export default function MexicoFinance(){ return <h2> Mexico Finance</h2>; }



