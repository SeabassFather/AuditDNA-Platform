import React from "react";
export default function FileUpload() {
  return (
    <input
      type="file"
      multiple
      style={{ margin: "0.5rem 0", padding: "0.5rem" }}
    />
  );
}
