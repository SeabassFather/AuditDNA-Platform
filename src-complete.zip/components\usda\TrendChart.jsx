import React from "react";
export default function TrendChart({ data }) {
  return (
    <div className="p-6 font-bold">
      TrendChart — render Recharts price/volume data here
    </div>
  );
}