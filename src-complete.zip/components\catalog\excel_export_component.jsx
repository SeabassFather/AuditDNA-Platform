import React from "react";

export default function ExcelExportComponent() {
  return (
    <div className="p-6">
      Excel Export Component module tab.
    </div>
  );
}