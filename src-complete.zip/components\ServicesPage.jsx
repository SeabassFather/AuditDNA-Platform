import React from "react";
import ServicesAccordion from "../components/ServicesAccordion";

export default function ServicesPage() {
  return (
    <div className="p-6">
      <ServicesAccordion />
    </div>
  );
}
