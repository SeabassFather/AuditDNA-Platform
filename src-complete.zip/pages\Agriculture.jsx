export default function Agriculture() {
  return <div className="p-8 text-3xl font-bold">Agriculture Module Coming Soon!</div>;
}
